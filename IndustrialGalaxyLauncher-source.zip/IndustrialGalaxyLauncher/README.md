# Industrial Galaxy Launcher (prototype)

Android starter project for the Industrial Galaxy Launcher concept.

## Current status
- Android launcher UI prototype.
- Login and registration are placeholders; no backend is connected.
- No EVE Echoes private-server protocol or original-client integration is implemented.
- This source project is not a built or tested APK.

## Cloud build
1. Upload this project to a GitHub repository from a browser.
2. Open the repository's **Actions** tab and enable workflows if prompted.
3. Run **Build Android APK** using **Run workflow**, or push a commit to `main`.
4. Download the `Industrial-Galaxy-debug-apk` artifact from the completed workflow run.
