package com.industrialgalaxy.launcher

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 16, 25)
    private val panel = Color.rgb(20, 31, 45)
    private val mint = Color.rgb(105, 215, 197)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("INDUSTRIAL GALAXY", 25, mint, true))
        root.addView(text("LAUNCHER  •  v0.1.0", 12, Color.LTGRAY, true))
        space(root, 22)
        root.addView(card("СОСТОЯНИЕ СЕРВЕРА", "Пока не подключён\nСерверная часть ещё не настроена."))
        space(root, 14)
        root.addView(text("ВХОД В АККАУНТ", 15, Color.WHITE, true))
        val login = edit("Логин")
        val pass = edit("Пароль", true)
        root.addView(login); root.addView(pass)
        val signIn = button("ВОЙТИ")
        root.addView(signIn)
        val register = button("СОЗДАТЬ АККАУНТ", false)
        root.addView(register)
        val info = text("Это демонстрационный интерфейс. Вход и регистрация заработают после подключения собственного сервера.", 12, Color.LTGRAY, false)
        root.addView(info)
        signIn.setOnClickListener { toast("Сервер авторизации пока не подключён") }
        register.setOnClickListener { toast("Регистрация станет доступна после настройки сервера") }
        space(root, 24)
        root.addView(text("БЫСТРЫЙ ДОСТУП", 15, Color.WHITE, true))
        root.addView(card("ЛИЧНЫЙ КАБИНЕТ", "Аккаунт • персонаж • баланс ISK"))
        root.addView(card("ПАНЕЛЬ АДМИНИСТРАТОРА", "Управление доступом и игровыми данными — после настройки backend"))
        root.addView(card("КЛИЕНТ EVE ECHOES", "Запуск оригинальной игры пока не настроен. Этот лаунчер сам по себе не подключает игру к приватному серверу."))
        space(root, 18)
        root.addView(text("Industrial Galaxy — ранний макет лаунчера, не приватный сервер EVE Echoes.", 11, Color.GRAY, false))
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }
    private fun edit(hintText: String, password: Boolean = false) = EditText(this).apply {
        hint = hintText; textSize = 15f; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        setPadding(dp(14), 0, dp(14), 0)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(panel); cornerRadius = dp(10).toFloat()
        }
        inputType = if (password) 129 else _text
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { bottomMargin = dp(10) }
    }
    private val _text = 1
    private fun button(label: String, primary: Boolean = true) = Button(this).apply {
        text = label; textSize = 13f
        setTextColor(if (primary) bg else mint)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(if (primary) mint else panel); cornerRadius = dp(10).toFloat()
            if (!primary) setStroke(dp(1), mint)
        }
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)).apply { bottomMargin = dp(9) }
    }
    private fun card(title: String, body: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(12), dp(15), dp(12))
        background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = dp(12).toFloat() }
        addView(text(title, 13, mint, true)); addView(text(body, 12, Color.LTGRAY, false))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) }
    }
    private fun space(parent: LinearLayout, h: Int) { parent.addView(android.view.View(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
